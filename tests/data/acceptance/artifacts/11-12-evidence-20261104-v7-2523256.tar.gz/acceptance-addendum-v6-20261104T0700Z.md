# 11-12 证据包 v6 addendum（2026-11-04T07:00Z）

## 为什么有 v6

v5 打于 14:03:33，A3 的 #3 采样证据提交于 14:03:31；v5 抓到的是旧工作树的
`services/market/evidence/MANIFEST.json`（`ced607bf…`），而 repo HEAD 为 `f105b582…`。
H4/H5 判 v5 **rejected-before-sign**（reason=`stale-market-evidence-manifest-race`），v5 冻结不改。

## 防竞态（H4 m03197 / H5 m03202）

- 本包用 `tests/data/acceptance/check_pack_matches_head.py` 逐条校验：包内每个 repo-mapped 文件
  的 `git hash-object` 必须等于 `<packed_from_commit>:<path>`，且该路径相对该 commit 无未提交改动。
- `manifest.packed_from_commit` 记录打包所依据的单一 commit；打包后不再以工作树为准。
- 包内-only 文件（`a19-artifacts/`、`transcripts/`、addendum/索引）显式以 `--allow-prefix` 声明。

## #3 绑定

- A3 证据 commit `72bada4`（生产 pin `7c177c6`）：`services/market/evidence/MANIFEST.json`=`f105b582…`，
  两档采样 JSON + `scripts/sample-restricted-403-p95.mjs` 均入包并复算。
- 数字以 JSON 为准：internal P95 2.268ms、c_end_display+hold P95 2.374ms；两档均 60/60 403 + no-store。
- A11 复跑：`pytest tests/contract` 61 passed；`check_entitlement_ordering.py` PASS（脚本 `8f75f900…`、gate `2660e4ef…`）。

## 其余绑定（不变）

- A19 rev4 `bd6b551e…`（18,021B）authoritative；rev3 `40fb117d…` historical；`results-prefix-g3-…`（`46dac615…`）pre_fix_baseline 在包内。
- #5 DOM 只引用 A12 v2 哈希 `5f866116…` / `885f2aa0…`，不复制整包。
- 0 字节墓碑 `http-attempts.jsonl` 只在 excluded；manifest 自哈希走 `SHA256SUMS-v6` 外部 sidecar。

## 未跟踪证据的 provenance 链（H5 m03202 第 1 条补充说明）

A19 的 `artifacts/logs/**` 未被 git 跟踪（`git ls-files …/logs` = 0），无法用 blob 比对；改为两条可复算链：

1. `a19-artifacts/**`：逐条对 A19 rev4 manifest（`bd6b551e…`，已 commit `b8e131c`）的 `files[].sha256/bytes` 校验；
   清单外文件（截图、rev3/rev4 manifest 自身）必须仍是 commit 中的 blob（`git hash-object`）。
2. `transcripts/**`：逐成员 sha 对已提交的 v5 tar（`tests/data/acceptance/artifacts/11-12-evidence-20261104-v5.tar.gz`，commit 中）校验。

以上由 `check_pack_matches_head.py --a19-manifest … --tar-provenance …` 执行，任一不符即 fail。
