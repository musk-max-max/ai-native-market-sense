# 红队产物索引（L74 / H5-R18）

收件人：A11（证据包打包方）；收件动作：2026-11-04 10:36（Asia/Shanghai），从工作树原路径复制入包。
来源：A19 `tests/adversarial/entitlement-bypass/`（runId `20261104T012350680Z`；REPORT.md §11 记录 A0 修复、A19 同命令/隔离库/新进程复验）。
哈希算法：SHA-256（按字节，不做换行符归一化）；文件权限/mtime 不入哈希；“收件时间”= 复制入包时刻；“源 mtime”= 文件产出时刻。

## 1. 入包文件（每件 path + sha256 + 字节 + 收件时间）

| # | 包内 path | 源 path | sha256 | 字节 | 源 mtime | 收件时间 | 权威版本 |
|---|---|---|---|---|---|---|---|
| 1 | `a19-artifacts/http-attempts-20261104T012350680Z.jsonl` | `tests/adversarial/entitlement-bypass/artifacts/http-attempts-20261104T012350680Z.jsonl` | `9ed2b522a2afeac0b2875dbe33cc772e4fea8c24156aa0d4869ed895dbc86160` | 175 行 | 2026-11-04T09:27:00+08:00 | 10:36 | **post-fix，run-scoped 原始往返日志** |
| 2 | `a19-artifacts/results.json` | 同目录 `results.json` | `46dac6158c1e13d044be33befa9f7119d9d595bb5adcf8c1cfdce518028eedaa` | 86120 | 2026-11-04T09:27:00+08:00 | 10:36 | **修复前基线**（46 项：44 PASS / 1 FAIL G3 P1 / 1 INFO；verdict=BYPASS_FOUND）——保留不覆盖，**R4 LEAK 记录不删** |
| 3 | `a19-artifacts/results-r4.json` | 同目录 `results-r4.json` | `d5bbe2f677ae0409b0704e459d8e7fe9a78f2b9676882727b407b1511817ef83` | 2016 | 2026-11-04T09:15:22+08:00 | 10:36 | **修复后权威**（R4 PASS：实例拒启/无 HTTP） |
| 4 | `a19-artifacts/trustproxy-guard.json` | 同目录 `trustproxy-guard.json` | `fee67c1bd6e4230930006bc5322cb40536f2bcffa4d9e510e524e752e879fe50` | 6252 | 2026-11-04T09:14:04+08:00 | 10:36 | **修复后权威**（四个 CIDR 全部 config 层拒启 = 4/4） |
| 5 | `a19-artifacts/trustproxy-guard-before-fix.json` | 同目录 `trustproxy-guard-before-fix.json` | `df23bec594869f507d0a518a66ae3e52cc0695e81c94bde74001973d12ad6de8` | 9753 | 2026-11-04T09:07:23+08:00 | 10:36 | 修复前对照（0/4） |
| 6 | `a19-artifacts/r4-before-fix.json` | 同目录 `r4-before-fix.json` | `73a57b43c24c3cc2331e5e04acad98506ec3f94251d1b1d6885a0266eb5895df` | 1965 | 2026-11-04T09:05:58+08:00 | 10:36 | 修复前对照（429→403 换桶 LEAK） |
| 7 | `a19-REPORT.md` | 同目录 `REPORT.md` | `01447211ec67fa4c233ac92bb27d06c2586d8a5381a50cb09e5e722122a27d02` | 19402 | 2026-11-04T09:15:34+08:00 | 10:36 | 报告正文（§11 作者/复验说明） |

**权威口径**：`results.json` = pre-fix 基线，只读保留；`results-r4.json` + `trustproxy-guard.json` = post-fix 权威；判断“修复是否生效”看后两者，`results.json` 中的 R4/TRUST_PROXY 失败记录不得删除（删=证据消毒）。

## 2. 拒收（H5-R18 第 1 条：提交值 ≠ 实算值，拒收并退回）

| 源 path | 提交值（A3 m02506） | 实算值（收件时） | 字节 | 源 mtime | 判定 |
|---|---|---|---|---|---|
| `services/market/evidence/hold-unreachable-raw-20261104.txt` | `730cddf5…`（仅前缀） | `f80562cab1225e2790805154bc1459210d0b1b681eaf8d018adf144bfabdaf67` | 2506 | 2026-11-04T09:21:36+08:00 | **REJECTED**：提交值与实算值不一致，未入包；已退回 A3 复核后重新提交（新文件名 + 新 sha） |

拒收不等于质疑内容；A11 自己的 `transcripts/07b_hold_unreachable.log` 已覆盖 #4 同场景，故 #4 判定不受影响。

## 3. 排除（保留路径可追，但不入包）

| 源 path | 原因 |
|---|---|
| `tests/adversarial/entitlement-bypass/artifacts/http-attempts.jsonl` | 0 字节（sha256 `e3b0c442…`，mtime 09:14:51），已被 run-scoped 文件取代；0 字节文件不入包，避免 manifest 的 size>0 规则被绕过 |

## 4. 判定口径（与 CI_MOUNT §7.1 行 7 一致）

`#7` = **行为 PASS（R4 修复后复跑）+ residual**。residual：公网 ingress `/v1` 外 404（A13，staging 就绪后）、H5 书面签字（11-12 前）。`results.json` 中 G3（prod profile 实例未起）保留为 FAIL：不因修复而回写结果，也不删负向记录。

## 5. 机械校验

`manifest-20261104T0235Z.json` 与本索引同包；`tests/data/acceptance/check_evidence_manifest.py --manifest … --archive …` 校验每件“存在 + size>0 + sha256 匹配”，并检查包内无未登记文件、拒收/排除文件未入包、权威标注齐全。CI 挂 `evidence-manifest-check`（`python3 -m pytest tests/data/test_evidence_manifest.py`）。

## v5 绑定（2026-11-04T06:30Z）

- A19 引用版 manifest：`a19-artifacts/evidence-manifest-20261104T023750101Z-rev4.json`，sha256 `bd6b551e…`（18,021 B / 39 files / revision 4 / commit `b8e131c`），authority=`authoritative`。
- rev3 `40fb117d…` 以 `historical` 保留；其前身 `caf6aca9…` 被就地改写、原文未保留，errata 见 rev4 顶层 `errata` 字段（不伪造）。
- 0 字节旧 `http-attempts.jsonl` 只在 `excluded`/tombstones 登记，不入包、不算证据。
