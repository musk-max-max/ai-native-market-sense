# 11-12 证据包 v4 addendum（2026-11-04T05:50Z）

v3（`11-12-evidence-20261104-v3.tar.gz`，sha `4b267717…`）已冻结不动；本 addendum 记录 v4 相对 v3 的变化与依据。

## v4 变化
1. A19 全新 run（runId `20261104T023750101Z`）：`results.json` 46 项 = 45 PASS / 1 INFO / 0 FAIL；G3 已 post-fix 重跑（`results-g3-postfix-20261104T023750101Z.json`，prod profile + DEPLOYMENT_UID 真起、dev-token 401），pre-fix 基线以新文件名保留为 `results-prefix-g3-20261104T012350680Z.json`（不覆盖、不删 R4 LEAK 记录）。
2. 原始往返日志：`http-attempts-20261104T023750101Z.jsonl`（run-scoped）与 `http-attempts-20261104T012350680Z.jsonl`（前一 run）均入包；`logs/20261104T023750101Z/` 为本次 run 的进程日志（逐条登记 sha256/bytes）。
3. 新增 #3 顺序/存在性泄漏验收：`check_entitlement_ordering.py`（受限档 403 短路、body 逐字节一致、正常档 404 保留、静态单次 control 读取），transcript `transcripts/14_entitlement_ordering.log`。
4. L76 开关三分：`env_switches.yaml` + `env-switch-inventory.md`（拒启 6 / 权威不可关 6 / 与判定无关 21，机械门禁 `tests/contract/test_env_switches.py` 4 passed）。
5. A2 display fixture 验收登记：bundle digest `7f2a1949…`（31 passed），见 `a2-evidence/display-fixture-digest-20261104.md`。
6. A3 证据四件：`hold-unreachable-raw-20261104-v4.txt`（权威 `259a54e9…`）、历史件 `hold-unreachable-raw-20261104.txt`（`f80562ca…`，末行陈旧自指哈希按 errata 留痕）、`RECEIPT-hold-unreachable-20261104.md`、`MANIFEST.json`。

## 未变/边界
- #5 DOM 渲染层归 A12；#7 公网 ingress 未验证、等 H5 签字；#4「真实网络不可达」只按 socket 级 connection refused 记录；getInstrument 双黑洞（control+serving 均不可达）1s 后 500 无行情数值为已知行为，记 #4 residual。
- C01 门禁保持红：`services/market/test/market-plugin.test.ts:396/:563` 负向样本，L83 已裁为扫描面 bug，等 H2 签署 `services/*/test/**` 测试宿主豁免后只改排除项，`services/*/src/**` 强度不变。
