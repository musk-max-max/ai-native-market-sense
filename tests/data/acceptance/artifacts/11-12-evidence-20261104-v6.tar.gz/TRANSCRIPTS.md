# 11-12 验收证据包 v2 —— 运行结果与口径说明

生成：A11（qa-contract-data），2026-11-04 09:19–09:21（Asia/Shanghai）
本包 supersedes v1（`11-12-evidence-20261104.tar.gz`，sha256 `feda377a…`），v1 不含运行 transcript，勿再引用为最终证据。

## 1. 复现锚点

| 项 | 值 |
|---|---|
| commit | `359874a375179af58b880b9736acf5485ca2b9ca`（分支 main；证据运行时工作树 clean；本包在 commit 之后新增 docs/transcripts，不影响代码与脚本） |
| 运行主机 | `ly-2.local`，Darwin 25.5.0 arm64 |
| 工具链 | Node v23.11.0；Python 3.12.2；oasdiff 1.35.0；psql (PostgreSQL) 16.15 (Homebrew) |
| DB | `postgresql://ms@127.0.0.1:55432/a13_verify`（A13 按 002 `c118eeb3` 重建的一次性 scratch 库；跑完 seed `--restore-fresh`、`hold=false`；seed/运行事件均 TEST） |
| API | 本机 `services/api/src/server.ts`（tsx），端口 18095–18100，每次验收新起进程，不复用修复者进程 |
| 驱动 | `/tmp/run_1112.sh`（A11 本地，不入仓；逐脚本命令在 transcript 头部） |
| 日常门禁 | `python3 -m pytest tests/contract tests/data -q` → 136 passed, 1 warning（2026-11-04 09:18） |

## 2. 原始 transcripts（13 个脚本 + 1 个 API 日志）

每个文件均含：`started_at / host / uname / node / python / oasdiff / psql / cwd / command / env(脱敏) / 原始 stdout+stderr / exit code / finished_at`。

| 条目 | transcript | exit | 关键输出 |
|---|---|---|---|
| #1 到期 fail-closed | transcripts/01_expiry_expired.log | 0 | 三接口 403 + instrument 200/tier=internal_eval + expired exact 1 |
| #4 no-store | transcripts/02_no_store.log | 0 | 8 调用 / 7 operation 全 no-store |
| #3 白名单 | transcripts/03_whitelist.log | 0 | data 恰 7 字段 |
| #8 裸启动 | transcripts/04_expiry_bare.log | 0 | 裸启动、三接口 403、tier=internal_eval |
| 限流条 | transcripts/05_rate_limit.log | 0 | 第 61 次 429、Retry-After、problem+json、XFF 不换桶 |
| #4 hold=true | transcripts/06_hold_active.log | 0 | 真 control 表 hold=true，三接口 403 |
| #4 stale 16min | transcripts/07_hold_stale.log | 0 | 真 control 表超时，三接口 403 |
| #4 读取不可达 | transcripts/07b_hold_unreachable.log | 0 | 见 §3 口径；三接口 403；p95=1.9ms（20 样本） |
| #5 文案一致 | transcripts/08_copy.log | 0 | 4/4 场景逐字节一致 |
| #6 事件 10 类 | transcripts/09_events.log | 0 | 41 条 / 10 类 / chain=0 / 双源一致 |
| #6 audit_gap | transcripts/10_audit_gap.log | 0 | 9 条负向均 SQLSTATE 23514、被拒后行数不变、exact 5 键、gap\|unknown=0 |
| 写失败分层 | transcripts/11_write_failure.log | 0 | 瞬态非阻断（200+degraded）、确定性阻断（启动拒绝）、名单 7/2 |
| display_safe | transcripts/12_display_safe.log | 0 | 4 场景全 fail-closed |
| — | transcripts/api_unreach.log | — | 不可达实例启动日志（监听 127.0.0.1:18100、healthz 200） |

## 3. #4「control 读取不可达」的一致结论（H4 m02412 要求）

- **方式：socket 级注入，不是真断网/不是代理黑洞。** 启动一个独立 API 实例，`DATABASE_URL=postgresql://ms@127.0.0.1:1/a13_verify`（本机未监听端口 → 连接被拒）；`ENTITLEMENT_HOLD_CHECK=1`、`ENTITLEMENT_TIER=internal_eval`、`DEPLOYMENT_UID=a11-unreach`。
- **观测**：进程正常启动、`/healthz` 200（`transcripts/api_unreach.log`）；三个行情接口均 403 `ENTITLEMENT_RESTRICTED`；20 次采样 P95=1.9ms（阈值 1500ms）。
- **结论**：gate 在 control 读不可达时 fail-closed，且延迟未被拖爆 —— 此条按 socket 级注入记 PASS；**不声称**“真实网络中断/分区”。
- 早前 08:53 的“不可达”记录与本次方法一致（同 p95=1.9ms），此前回执写“未取证”按从严口径，现以本 transcript 为准。

## 4. #7 判定：PARTIAL（H4 m02412/m02420）

- **改代码者**：A0 —— `services/api/src/config.ts`（mtime 2026-11-04 09:09），实现 `TRUST_PROXY` 宽网段拒启。
- **复验者**：A19（攻方），独立于修改者；同一命令、同一隔离库 `market_sense_a19`、同一端口，**每次新起进程**，非修复者进程复用。见 `a19-REPORT.md` §11 与 `a19-artifacts/trustproxy-guard.json`、`results-r4.json`。
- **结果**：`trustproxy-guard.mjs` 4/4 拒启（exit 1、stderr 首行含 TRUST_PROXY、listenedPort=false）；`run.mjs --only=R4` 修复后实例拒启/无 HTTP → R4 PASS。
- **仍为 PARTIAL 的原因**：五组攻击用例（存储注毒/伪造头/路径/mock 构建/SW 缓存）在当前证据里只有 BLOCKED 记录、未包含其完整运行 transcript；公网 ingress 未验证；H5 书面签字未落。TRUST_PROXY 4/4 只覆盖“启动拒绝 + ingress 守卫”这一面。
- **#5**：DOM/渲染层归 A12，H4 不签，本包不含该条证据。

## 5. 本次未取证项（与回执一致）

1. #5 DOM/渲染层数值泄漏断言 —— A12 `tests/e2e` 域。
2. #7 公网 ingress（`/v1` 之外外部 404）—— A13 未配 `PUBLIC_BASE_URL`；H5 对 R4 的书面接受未落。
3. #7 五组攻击用例的完整 transcript —— A19 侧仅提供 `results.json` 摘要与 REPORT；本包附 REPORT + 两份关键 JSON，未附全量运行日志。

## 6. 文件清单

- 001/002 DDL、`docs/reference/event-payloads.json`、`entitlement-reasons.json`
- 13 个验收脚本（12 py + 1 ts）、`tests/contract/CI_MOUNT.md`、`tests/data/quality_policy.yaml`
- seed/测试脚本：`infra/db/seed-entitlement-audit.sh`、`seed-serving-fixture.sh`、`test-entitlement-gap.sh`
- `transcripts/`（14 个原始日志）、`a19-REPORT.md`、`a19-artifacts/`、`git-info.txt`

## 7. v2 打包约束

- 本包封版后不再修改；如需变更，另出 `-v3`。
- 包内不放自身哈希（避免自引用）；sha256 见 `tests/data/acceptance/artifacts/SHA256SUMS` 与 A11 回执。
