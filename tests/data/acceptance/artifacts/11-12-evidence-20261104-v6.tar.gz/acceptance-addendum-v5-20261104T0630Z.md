# 11-12 证据包 v5 addendum（2026-11-04T06:30Z）

本包只替换 A19 引用版与若干说明，**不重跑任何测试**；v4（tar `fbc353cc…`）冻结不动，保留作历史快照。

## 绑定

- A19 引用版：`a19-artifacts/evidence-manifest-20261104T023750101Z-rev4.json`
  - sha256 `bd6b551e…`（18,021 B；39 files；1 tombstone；revision 4；commit `b8e131c`）
  - 顶层 `errata`：`rev3_as_delivered=caf6aca9…`、`in_place_rewrite_to=40fb117d…`、`original_bytes_retained=false`（原文未保留，不伪造）
  - `results.json` 的 `supersedes`：`archived_path` + `archived_sha256=46dac615…` + `phase="pre-fix"`；归档件 `results-prefix-g3-20261104T012350680Z.json` 在包内且复算一致
- rev3 manifest（`40fb117d…`，v4 当时的引用版）作为 **historical** 保留在包内，note：被 rev4 取代（errata 见 rev4）。
- #5 DOM 绑定（A12 v2，H5 已签 DOM 层）：tar `5f866116…`、manifest `885f2aa0…`；只引用哈希，不复制整包。
  A12 归一化规则：其 manifest 为 repo-relative（含 `run_root/`）、tar 为包相对，比对前剥 `run_root/` 前缀，禁止裸字符串比；字段名 `bytes`。
- 证据指针：rev4 的 `artifacts/...` 为包内相对路径；本包 `a19-artifacts/` 前缀映射后逐条命中，0 字节旧 `http-attempts.jsonl` 仅在 `excluded`/tombstone 登记。
- 未取证（不计 PASS）：#5 DOM 渲染（A12 v2，H5 签）、#7 公网 ingress（A13）、#4 真实网络不可达 P95（A3 证据为 socket 级）。

## C01

A3 已将 `services/market/test/market-plugin.test.ts` 的 `600519.SH` 改为 canonical `SSE:600519`；C01 门禁转绿，未启用 L83 目录级测试宿主豁免（H4 m03103：不默认豁免）。
